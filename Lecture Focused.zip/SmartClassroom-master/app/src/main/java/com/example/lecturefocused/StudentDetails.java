package com.example.lecturefocused;

public class StudentDetails {
    public  String  Users;
    public String OnScreen_time;
    public String Joiningtime;
    public  String Leavingtime;
    public  String SeatNo;
    public String Present;


}
